#!/usr/bin/env python
# -*- coding:utf-8 -*-


import requests
from lxml import etree

import os
import time
from apscheduler.schedulers.blocking import BlockingScheduler

import smtplib
from email.header import Header
from email.mime.text import MIMEText

import jinja2

import logging

logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)
handler = logging.FileHandler("logs/log.log")
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)


smtp_host = 'smtp.163.com'  # SMTP 服务器主机 "smtp.163.com"
smtp_port = 465  # SMTP 服务器端口号

# 发送者,我的另一个邮箱.得有2个邮箱,并且开通smtp授权码,才可以使用代码发送邮件.
from_addr = ''
# smtp/imap 授权码
password = ''  # 163授权
# 接收者,自己的邮箱
to_addr = ''

version_dic = {'iPhone 12 Pro': 'https://ipsw.me/iPhone13,3', 'iPhone 12 Pro Max': 'https://ipsw.me/iPhone13,4',
               'iPhone 12 mini': 'https://ipsw.me/iPhone13,1', 'iPhone 12': 'https://ipsw.me/iPhone13,2',
               'iPhone SE (2020)': 'https://ipsw.me/iPhone12,8', 'iPhone 11 Pro': 'https://ipsw.me/iPhone12,3',
               'iPhone 11': 'https://ipsw.me/iPhone12,1', 'iPhone 11 Pro Max': 'https://ipsw.me/iPhone12,5',
               'iPhone XR': 'https://ipsw.me/iPhone11,8', 'iPhone XS Max (China)': 'https://ipsw.me/iPhone11,4',
               'iPhone XS': 'https://ipsw.me/iPhone11,2', 'iPhone XS Max': 'https://ipsw.me/iPhone11,6',
               'iPhone X (GSM)': 'https://ipsw.me/iPhone10,6', 'iPhone X (Global)': 'https://ipsw.me/iPhone10,3',
               'iPhone 8 Plus (Global)': 'https://ipsw.me/iPhone10,2',
               'iPhone 8 Plus (GSM)': 'https://ipsw.me/iPhone10,5', 'iPhone 8 (GSM)': 'https://ipsw.me/iPhone10,4',
               'iPhone 8 (Global)': 'https://ipsw.me/iPhone10,1', 'iPhone 7 Plus (GSM)': 'https://ipsw.me/iPhone9,4',
               'iPhone 7 (GSM)': 'https://ipsw.me/iPhone9,3', 'iPhone 7 Plus (Global)': 'https://ipsw.me/iPhone9,2',
               'iPhone 7 (Global)': 'https://ipsw.me/iPhone9,1', 'iPhone SE': 'https://ipsw.me/iPhone8,4',
               'iPhone 6s+': 'https://ipsw.me/iPhone8,2', 'iPhone 6s': 'https://ipsw.me/iPhone8,1',
               'iPhone 6': 'https://ipsw.me/iPhone7,2', 'iPhone 6+': 'https://ipsw.me/iPhone7,1',
               'iPhone 5s (GSM)': 'https://ipsw.me/iPhone6,1', 'iPhone 5c (Global)': 'https://ipsw.me/iPhone5,4',
               'iPhone 5c (GSM)': 'https://ipsw.me/iPhone5,3', 'iPhone 5s (Global)': 'https://ipsw.me/iPhone6,2',
               'iPhone 5 (Global)': 'https://ipsw.me/iPhone5,2', 'iPhone 5 (GSM)': 'https://ipsw.me/iPhone5,1',
               'iPhone 4 (GSM / 2012)': 'https://ipsw.me/iPhone3,2', 'iPhone 4[S]': 'https://ipsw.me/iPhone4,1',
               'iPhone 4 (CDMA)': 'https://ipsw.me/iPhone3,3', 'iPhone 4 (GSM)': 'https://ipsw.me/iPhone3,1',
               'iPhone 3G[S]': 'https://ipsw.me/iPhone2,1', 'iPhone 3G': 'https://ipsw.me/iPhone1,2',
               'iPhone 2G': 'https://ipsw.me/iPhone1,1'}


tmp_se = 0
tmp_se2020 = 0

def get_useful_version(product):
    """
    获取iphone可用的降级固件
    :param product:iphone型号
    :return:降级固件名称列表
    """
    url = version_dic.get(product)
    if not url:
        return [f'没有该型号的数据{product}'], False
    ret = requests.get(url, headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
    },timeout=(3.1, 10))
    if ret.status_code == 200:
        tree = etree.HTML(ret.text)
        lists = tree.xpath('/html/body/div/div[1]/div[2]/table[1]/tr')
        ss = list(map(lambda x: x.xpath('.//text()'), lists))
        version_lis = list(map(lambda x: (product, x[3], x[5].strip(), x[7].strip(), x[9]), ss))
        return version_lis, True

    return ['网络波动,请稍候再试'], False


def get_fanxin_products():
    url = "https://www.apple.com.cn/shop/refurbished/mac"
    fanxin_list = []
    flag = False
    ret = requests.get(url, headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'
    },timeout=(3.1, 10))
    if ret.status_code == 200:
        tree = etree.HTML(ret.text)
        lists = tree.xpath('//div[@class="refurbished-category-grid-no-js"]/ul/li')
        for li in lists:
            if 'M1' in li.xpath("./h3/a/text()")[0].strip() and not flag:
                flag = True
            fanxin_list.append((li.xpath("./h3/a/text()")[0].strip(), li.xpath('./div/text()')[0].strip()))

    return flag, fanxin_list


def my_job():
    ret_se = get_useful_version('iPhone SE')
    ret_se2020 = get_useful_version('iPhone SE (2020)')

    global tmp_se
    global tmp_se2020

    if any([ret_se[1] and len(ret_se[0]) != tmp_se, ret_se2020[1] and len(ret_se2020[0]) != tmp_se2020]):
        tmp_se = len(ret_se[0])
        tmp_se2020 = len(ret_se2020[0])

        logger.info(f"发现新的固件,降级通道")
        text = getContent(data=ret_se[0] + ret_se2020[0],file='index.html')
        title = "IPSW 苹果固件降级查询"
        send_email(text, title=title, subtype='html')


def my_fanxin_job():
    """
    一小时查一次即可
    :return:
    """
    flag, result = get_fanxin_products()
    if flag:
        text = getContent(data=result, file='fanxin.html')
        title = '苹果翻新产品查询'
        send_email(text, title=title, subtype='html')


def render(tplPath, **kvargs):
    """跨平台相关设置"""
    if os.name == 'nt':
        currPath = '.\\'
    else:
        currPath = './'

    path, fileName = os.path.split(tplPath)
    return jinja2.Environment(
        loader=jinja2.FileSystemLoader(path or currPath)
    ).get_template(fileName).render(**kvargs)


"""获取content"""


def getContent(data, file):
    data = data
    localDict = locals()
    content = render(file, **localDict)
    return content



def message_me():
    text = f"今天是{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))},IPSW查询服务运行正常"
    title = "IPSW 查询运行正常"
    logger.info('运行正常,线程OK')
    send_email(text, title)


def send_email(text, title, subtype='plain'):
    # 创建 MIMEText 对象
    msg = MIMEText(_text=text, _subtype=subtype, _charset="utf-8")  # _text="邮件内容"
    msg["Subject"] = Header(s=title, charset="utf-8")  # 标题
    msg["From"] = Header(s=from_addr)  # 发送者
    msg["To"] = Header(s=to_addr)  # 接收者
    try:
        smtp_obj = smtplib.SMTP_SSL(host=smtp_host, port=smtp_port)
        smtp_obj.login(user=from_addr, password=password)
        smtp_obj.sendmail(from_addr=from_addr, to_addrs=to_addr, msg=msg.as_string())
        smtp_obj.quit()
        print("发送成功")
    except smtplib.SMTPException as e:
        print(e)

def clean_log():
    # 定是情理入职文件
    f = open("logs/log.log", "w", encoding='utf-8')
    f.close()
    f = open("logs/error.log", "w", encoding='utf-8')
    f.close()


if __name__ == '__main__':

    clean_log()
    my_job()
    my_fanxin_job()

    sched = BlockingScheduler()
    # 每隔10mim执行一次my_job函数，访问苹果降级固件网站
    sched.add_job(my_job, 'interval', minutes=30)
    sched.add_job(my_fanxin_job, 'interval', hours=1)
    # sched.add_job(my_job, 'cron',hour=14, minute=28)
    sched.add_job(message_me, 'cron', hour='0,6,12,18')
    sched.add_job(clean_log, 'interval', days=7)
    sched.start()

